import{l as o,d as r}from"../chunks/BG20cPq2.js";export{o as load_css,r as start};
