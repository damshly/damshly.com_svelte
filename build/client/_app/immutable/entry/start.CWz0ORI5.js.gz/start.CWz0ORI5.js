import{l as o,d as r}from"../chunks/D34tXvnH.js";export{o as load_css,r as start};
