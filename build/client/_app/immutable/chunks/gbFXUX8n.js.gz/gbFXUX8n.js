import{X as o}from"./DT1BJyTm.js";const s=o;export{s as d};
